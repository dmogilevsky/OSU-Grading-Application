#!/bin/bash
for i in {1. .81}
do
  wget https://www.setgame.com/sites/all/modules/setgame_set/assets/images/new/${i}.png
done

